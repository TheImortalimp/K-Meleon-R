const Cu = Components.utils;
const Ci = Components.interfaces;
Cu.import("resource://gre/modules/Services.jsm");
Cu.import("resource://gre/modules/XPCOMUtils.jsm");

function setEngine() {
    let searchEngineName;
    try {
      searchEngineName = Services.prefs.getComplexValue("kmeleon.general.searchEngineName", Ci.nsIPrefLocalizedString);
    } catch (ex) {
      searchEngineName = Services.prefs.getCharPref("kmeleon.general.searchEngineName", '');
    }
    
	  //var searchEngineName = Services.search.defaultEngine.name;
	  let searchText = document.getElementById("searchText");	  
    searchText.addEventListener("blur", function searchText_onBlur() {
        searchText.removeEventListener("blur", searchText_onBlur);
        searchText.removeAttribute("autofocus");
    });
    
    searchText.placeholder = searchEngineName;
    /*var submission = engine.getSubmission("_searchTerms_", null, "homepage");
    var searchURL = submission.uri.spec;//Services.prefs.getComplexValue("kmeleon.general.searchEngine", Ci.nsIPrefLocalizedString);
    searchText.setAttribute("data-url", searchURL);
    */
}

window.addEventListener('load', function () {
    Services.prefs.addObserver("kmeleon.general.searchEngineName", setEngine, false);
    setEngine();
});

window.addEventListener('beforeunload', function () {
    Services.prefs.removeObserver("kmeleon.general.searchEngineName", setEngine);
});
	
const SEARCH_FALLBACK = "https://www.bing.com/search?q=";

// Search providers for the start page: Google (default) or Microsoft Copilot.
const PROVIDER_PREF = "kmeleon.search.provider";
const PROVIDERS = {
    bing: { label: "Bing", url: "https://www.bing.com/search?q=_searchTerms_" },
    google: { label: "Google", url: "https://www.google.com/search?q=_searchTerms_" },
    copilot: { label: "Copilot", url: "https://www.bing.com/copilotsearch?q=_searchTerms_" },
    gemini: { label: "Gemini", url: "https://www.google.com/search?udm=50&q=_searchTerms_" }
};
const GEMINI_HOME = "https://gemini.google.com/app";
const COPILOT_HOME = "https://www.bing.com/copilotsearch";

function getProvider() {
    try {
        let p = Services.prefs.getCharPref(PROVIDER_PREF);
        if (PROVIDERS[p]) return p;
    } catch (ex) {}
    return "bing";
}

const PROVIDER_ORDER = ["bing", "google", "copilot", "gemini"];

function applyProvider() {
    let p = PROVIDERS[getProvider()];
    document.getElementById("searchText").placeholder = p.label;
    document.getElementById("searchProvider").value = "Search: " + p.label;
}

function getSearchURL() {
    return PROVIDERS[getProvider()].url;
}

function getLegacySearchURL() {
    // The search service may be missing in this build, so fall back to the prefs.
    try {
        let submission = Services.search.defaultEngine.getSubmission("_searchTerms_", null, "homepage");
        if (submission && submission.uri) return submission.uri.spec;
    } catch (ex) {}
    try {
        return Services.prefs.getComplexValue("kmeleon.general.searchEngine", Ci.nsIPrefLocalizedString).data + "_searchTerms_";
    } catch (ex) {}
    try {
        return Services.prefs.getCharPref("kmeleon.general.searchEngine") + "_searchTerms_";
    } catch (ex) {}
    return SEARCH_FALLBACK + "_searchTerms_";
}

function onSearchSubmit(aEvent)
{
    aEvent.preventDefault();
    var searchURL = getSearchURL();
    var searchTerms = document.getElementById("searchText").value;
   
    if (searchURL && searchTerms.length > 0) {

        const SEARCH_TOKEN = "_searchTerms_";
        let searchPostData = document.documentElement.getAttribute("searchEnginePostData");
        if (searchPostData) {
            // Check if a post form already exists. If so, remove it.
            const POST_FORM_NAME = "searchFormPost";
            let form = document.forms[POST_FORM_NAME];
            if (form) {
                form.parentNode.removeChild(form);
            }

            // Create a new post form.
            form = document.body.appendChild(document.createElement("form"));
            form.setAttribute("name", POST_FORM_NAME);
            // Set the URL to submit the form to.
            form.setAttribute("action", searchURL.replace(SEARCH_TOKEN, searchTerms));
            form.setAttribute("method", "post");

            // Create new <input type=hidden> elements for search param.
            searchPostData = searchPostData.split("&");
            for (let postVar of searchPostData) {
                let [name, value] = postVar.split("=");
                if (value == SEARCH_TOKEN) {
                    value = searchTerms;
                }
                let input = document.createElement("input");
                input.setAttribute("type", "hidden");
                input.setAttribute("name", name);
                input.setAttribute("value", value);
                form.appendChild(input);
            }
            // Submit the form.
            form.submit();
        } else {
            searchURL = searchURL.replace(SEARCH_TOKEN, encodeURIComponent(searchTerms));
            window.location.href = searchURL;
        }
    }
}

/* ---- K-Meleon-R speed dial ---- */
const DIAL_PREF = "kmeleon.browser.speeddial2";
const DIAL_OPERA_PREF = "kmeleon.browser.speeddial.opera";
const DIAL_DEFAULTS = [
    { title: "MSN", url: "https://www.msn.com/en-gb" },
    { title: "Google", url: "https://www.google.com/" },
    { title: "YouTube", url: "https://www.youtube.com/" },
    { title: "Bandcamp", url: "https://bandcamp.com/" },
    { title: "Spotify", url: "https://open.spotify.com/" },
    { title: "Opera", url: "https://www.opera.com/" },
    { title: "Opera GX", url: "https://www.opera.com/gx" }
];
const THUMB_SIZE = 128;
let pendingImage = "";
let editIndex = -1;

function loadDial() {
    try {
        let list = JSON.parse(Services.prefs.getCharPref(DIAL_PREF));
        if (Array.isArray(list)) return migrateDial(list);
    } catch (ex) {}
    try { Services.prefs.setCharPref(DIAL_OPERA_PREF, "1"); } catch (ex) {}
    return DIAL_DEFAULTS.slice();
}

// Existing speed dials get the Opera and Opera GX tiles once, after their own tiles.
// Removing them afterwards sticks, because the flag is stored.
function migrateDial(list) {
    let done = false;
    try { done = Services.prefs.getCharPref(DIAL_OPERA_PREF) == "1"; } catch (ex) {}
    if (done) return list;
    DIAL_DEFAULTS.slice(-2).forEach(function (entry) {
        let have = list.some(function (e) { return e && String(e.url).replace(/\/$/, "") == entry.url.replace(/\/$/, ""); });
        if (!have) list.push({ title: entry.title, url: entry.url });
    });
    saveDial(list);
    try { Services.prefs.setCharPref(DIAL_OPERA_PREF, "1"); } catch (ex) {}
    return list;
}

function saveDial(list) {
    Services.prefs.setCharPref(DIAL_PREF, JSON.stringify(list));
}

function isAllowedDialUrl(url) {
    return /^(https?:\/\/|windowsdefender:\/\/)/i.test(url);
}

function iconClass(url) {
    let host = "", path = "";
    try { let u = new URL(url); host = u.hostname; path = u.pathname; } catch (ex) {}
    if (/(^|\.)opera\.com$/i.test(host)) return /^\/gx(\/|$)/i.test(path) ? "icon-operagx" : "icon-opera";
    if (/wikipedia\.org$/i.test(host)) return "icon-wikipedia";
    if (/github\.com$/i.test(host)) return "icon-github";
    if (/(youtube\.com|youtu\.be)$/i.test(host)) return "icon-youtube";
    if (/reddit\.com$/i.test(host)) return "icon-reddit";
    if (/^windowsdefender:/i.test(url)) return "icon-shield";
    return "";
}

function isImageData(s) {
    return typeof s == "string" && /^data:image\/(png|jpeg|gif|webp);base64,[A-Za-z0-9+\/=]+$/.test(s);
}

// Shrinks a picked image file to a small PNG data URL so it fits in a pref.
function readThumbnail(file, done) {
    let reader = new FileReader();
    reader.onload = function () {
        let img = new Image();
        img.onload = function () {
            let canvas = document.createElement("canvas");
            canvas.width = canvas.height = THUMB_SIZE;
            let ctx = canvas.getContext("2d");
            let scale = Math.min(THUMB_SIZE / img.width, THUMB_SIZE / img.height);
            let w = img.width * scale, h = img.height * scale;
            ctx.drawImage(img, (THUMB_SIZE - w) / 2, (THUMB_SIZE - h) / 2, w, h);
            done(canvas.toDataURL("image/png"));
        };
        img.onerror = function () { done(""); };
        img.src = reader.result;
    };
    reader.onerror = function () { done(""); };
    reader.readAsDataURL(file);
}

// Uses the site's own logo (favicon); falls back to a letter when unavailable.
function applySiteLogo(icon, url, title) {
    let origin = "";
    try { origin = new URL(url).origin; } catch (ex) {}
    let letter = function () {
        icon.className += " letter";
        icon.textContent = (title || "?").charAt(0).toUpperCase();
    };
    if (!/^https?:/i.test(origin)) { letter(); return; }
    let probe = new Image();
    probe.onload = function () {
        if (probe.width < 2) { letter(); return; }
        icon.className += " fav";
        icon.style.backgroundImage = 'url("' + origin + '/favicon.ico")';
    };
    probe.onerror = letter;
    probe.src = origin + "/favicon.ico";
}

function makeTile(cls, label, iconClassName) {
    let tile = document.createElement("div");
    tile.className = "tile " + cls;
    let icon = document.createElement("span");
    icon.className = "icon " + (iconClassName || "");
    let name = document.createElement("span");
    name.className = "name";
    name.textContent = label;
    tile.appendChild(icon);
    tile.appendChild(name);
    return tile;
}

function renderDial() {
    let root = document.getElementById("speedDial");
    while (root.firstChild) root.removeChild(root.firstChild);
    let list = loadDial();

    list.forEach(function (entry, i) {
        if (!entry || !isAllowedDialUrl(String(entry.url))) return;
        let title = String(entry.title || entry.url);
        let known = iconClass(String(entry.url));
        let custom = isImageData(entry.img);
        let tile = makeTile("site", title, custom ? "custom" : known);
        let iconEl = tile.firstChild;
        if (custom) iconEl.style.backgroundImage = 'url("' + entry.img + '")';
        else if (!known) applySiteLogo(iconEl, String(entry.url), title);
        tile.title = entry.url;
        let edit = document.createElement("span");
        edit.className = "edit";
        edit.textContent = "\u270e";
        edit.title = "Change name, address or picture";
        edit.addEventListener("click", function (e) {
            e.stopPropagation();
            openDialForm(i);
        });
        tile.appendChild(edit);
        tile.addEventListener("click", function () {
            window.location.href = entry.url;
        });
        let remove = document.createElement("span");
        remove.className = "remove";
        remove.textContent = "\u00d7";
        remove.title = "Remove";
        remove.addEventListener("click", function (e) {
            e.stopPropagation();
            list.splice(i, 1);
            saveDial(list);
            renderDial();
        });
        tile.appendChild(remove);
        root.appendChild(tile);
    });

    let add = makeTile("add", "Add site", "");
    add.addEventListener("click", function () { openDialForm(-1); });
    root.appendChild(add);
}

function openDialForm(index) {
    editIndex = index;
    pendingImage = "";
    let entry = index >= 0 ? loadDial()[index] : null;
    document.getElementById("dialTitle").value = entry ? entry.title || "" : "";
    document.getElementById("dialUrl").value = entry ? entry.url || "" : "";
    document.getElementById("dialImage").value = "";
    document.getElementById("dialImageStatus").textContent = entry && isImageData(entry.img) ? "Custom picture set" : "";
    document.getElementById("dialClearImage").className = entry && isImageData(entry.img) ? "" : "hidden";
    document.getElementById("dialForm").className = "";
    document.getElementById("dialTitle").focus();
}

function onDialSave(aEvent) {
    aEvent.preventDefault();
    let url = document.getElementById("dialUrl").value.trim();
    if (!/^[a-z][a-z0-9+.-]*:/i.test(url)) url = "https://" + url;
    if (!/^https?:\/\//i.test(url)) return;
    let title = document.getElementById("dialTitle").value.trim() || url.replace(/^https?:\/\//i, "");
    let list = loadDial();
    let entry = { title: title, url: url };
    if (editIndex >= 0 && list[editIndex]) {
        if (isImageData(list[editIndex].img)) entry.img = list[editIndex].img;
        list[editIndex] = entry;
    } else {
        list.push(entry);
    }
    if (pendingImage === null) delete entry.img;
    else if (pendingImage) entry.img = pendingImage;
    saveDial(list);
    onDialCancel();
    renderDial();
}

function onDialCancel() {
    document.getElementById("dialTitle").value = "";
    document.getElementById("dialUrl").value = "";
    document.getElementById("dialImage").value = "";
    document.getElementById("dialImageStatus").textContent = "";
    document.getElementById("dialForm").className = "hidden";
    pendingImage = "";
    editIndex = -1;
}

window.addEventListener("load", function () {
    document.getElementById("dialCancel").addEventListener("click", onDialCancel);
    document.getElementById("dialImage").addEventListener("change", function () {
        let file = this.files && this.files[0];
        if (!file) return;
        readThumbnail(file, function (data) {
            pendingImage = data;
            document.getElementById("dialImageStatus").textContent = data ? "Picture ready" : "Could not read that image";
        });
    });
    document.getElementById("dialClearImage").addEventListener("click", function () {
        pendingImage = null;
        document.getElementById("dialImageStatus").textContent = "Picture will be removed";
    });
    document.getElementById("searchProvider").addEventListener("click", function () {
        Services.prefs.setCharPref(PROVIDER_PREF, PROVIDER_ORDER[(PROVIDER_ORDER.indexOf(getProvider()) + 1) % PROVIDER_ORDER.length]);
        applyProvider();
    });
    document.getElementById("askCopilot").addEventListener("click", function () {
        let q = document.getElementById("searchText").value.trim();
        window.location.href = q ? PROVIDERS.copilot.url.replace("_searchTerms_", encodeURIComponent(q)) : COPILOT_HOME;
    });
    applyProvider();
    // Google AI Mode (udm=50) is Gemini-powered search and accepts the query in the URL.
    document.getElementById("askGemini").addEventListener("click", function () {
        let q = document.getElementById("searchText").value.trim();
        window.location.href = q ? PROVIDERS.gemini.url.replace("_searchTerms_", encodeURIComponent(q)) : GEMINI_HOME;
    });
    renderDial();
});


// ---- Theme toggle: dark (default) / light / sand / sky / system ----
var THEME_PREF = "kmeleon.display.theme";
var THEME_EFFECTIVE = "kmeleon.theme.effective";
var THEME_MODES = ["dark", "light", "sand", "sky", "system"];
var THEME_LABELS = { dark: "Dark", light: "Light", sand: "Sand", sky: "Sky", system: "System" };
var themeObserver = {
    observe: function () { applyTheme(); }
};

function getThemeMode() {
    try {
        let m = Services.prefs.getCharPref(THEME_PREF);
        if (THEME_MODES.indexOf(m) >= 0) return m;
    } catch (e) {}
    return "dark";
}

function applyTheme() {
    let mode = getThemeMode();
    let eff = mode;
    if (mode == "system") {
        try { eff = window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark"; } catch (e) { eff = "dark"; }
    }
    document.documentElement.setAttribute("data-theme", eff);
    let btn = document.getElementById("themeToggle");
    if (btn) btn.value = "Theme: " + THEME_LABELS[mode];
}

// Called by the native shell so the page follows the toolbar's Theme button.
window.kmrSetTheme = function (mode) {
    if (THEME_MODES.indexOf(mode) < 0) return;
    Services.prefs.setCharPref(THEME_PREF, mode);
    applyTheme();
};

window.addEventListener("load", function () {
    applyTheme();
    try {
        Services.prefs.addObserver(THEME_PREF, themeObserver, false);
        Services.prefs.addObserver(THEME_EFFECTIVE, themeObserver, false);
    } catch (e) {}
    try {
        window.matchMedia("(prefers-color-scheme: light)").addEventListener("change", applyTheme);
    } catch (e) {}
    document.getElementById("themeToggle").addEventListener("click", function () {
        let next = THEME_MODES[(THEME_MODES.indexOf(getThemeMode()) + 1) % THEME_MODES.length];
        window.kmrSetTheme(next);
        try { window.chrome.webview.postMessage("theme:" + next); } catch (e) {}
    });
});

window.addEventListener("beforeunload", function () {
    try {
        Services.prefs.removeObserver(THEME_PREF, themeObserver);
        Services.prefs.removeObserver(THEME_EFFECTIVE, themeObserver);
    } catch (e) {}
});
